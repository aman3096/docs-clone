import React from 'react';
import './App.css';
import RichText from './Richtext';
// Import React dependencies.

function App() {
  
  

  return (
    <React.Fragment>   
       <RichText/>
   
    </React.Fragment>

  )
}

export default App;
